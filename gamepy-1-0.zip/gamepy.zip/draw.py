canvas = None

class Draw:
    @staticmethod
    def set_canvas(c):
        global canvas
        canvas = c

    @staticmethod
    def text(text, pos, size=(20, 20), color="white"):
        if canvas:
            x, y = pos
            w, h = size
            canvas.create_text(x, y, text=text, fill=color, font=("Arial", w))

draw = Draw()
