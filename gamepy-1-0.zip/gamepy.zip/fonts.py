class Fonts:
    @staticmethod
    def default():
        return ("Arial", 20)

fonts = Fonts()
