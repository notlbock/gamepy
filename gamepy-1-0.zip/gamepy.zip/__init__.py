from .core import *
from .draw import draw
from .fonts import fonts
from . import events as Events

print("GAMEPY (1.0) (TEST VERSION)")
print("GAMEPY INSPIRED BY PYGAME")
print("Gamepy website: ")
