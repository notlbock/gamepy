import tkinter as tk
from . import fonts, events
from .draw import draw

window = None
canvas = None
running = False
_fps = 60
_current_font = None

def game(window_size=(800, 600)):
    """Initialize game window"""
    global window, canvas, running
    width, height = window_size
    window = tk.Tk()
    window.title("GamePy")
    running = True
    window.protocol("WM_DELETE_WINDOW", _on_quit)

    canvas = tk.Canvas(window, width=width, height=height, bg="black")
    canvas.pack()
    draw.set_canvas(canvas)

def setfps(fps):
    global _fps
    _fps = fps

def setFont(font):
    global _current_font
    _current_font = font

def _on_quit():
    global running
    events.QUIT = True
    running = False

def run(update_func):
    """Run the main game loop"""
    def loop():
        if not running:  # check running flag every iteration
            window.destroy()
            return
        canvas.delete("all")
        update_func()
        window.after(int(1000/_fps), loop)
    loop()
    window.mainloop()
